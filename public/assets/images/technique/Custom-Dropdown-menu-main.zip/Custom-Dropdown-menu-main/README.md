# Custom-Dropdown-menu
custom dropdown select menu using react js and tailwind css - easy way

npm i
npm run dev
